/* =====================================================================
   Inline SVG icon set (offline, no web-font). Renders instantly,
   never flashes a name, never reserves wrong width.  alagar-site-3d
   ===================================================================== */
(function () {
  "use strict";
  var I = {
    menu:'<line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>',
    close:'<line x1="5" y1="5" x2="19" y2="19"/><line x1="19" y1="5" x2="5" y2="19"/>',
    expand_more:'<polyline points="6 9 12 15 18 9"/>',
    chevron_right:'<polyline points="9 6 15 12 9 18"/>',
    keyboard_arrow_up:'<polyline points="6 15 12 9 18 15"/>',
    arrow_forward:'<line x1="4" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/>',
    check_circle:'<circle cx="12" cy="12" r="9"/><polyline points="8 12 11 15 16 9"/>',
    call:'<path d="M5 4h3l2 5-2.4 1.4a11 11 0 0 0 5 5L14 13l5 2v3a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
    mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><polyline points="3 7 12 13 21 7"/>',
    location_on:'<path d="M12 22s7-6.5 7-12a7 7 0 0 0-14 0c0 5.5 7 12 7 12z"/><circle cx="12" cy="10" r="2.5"/>',
    send:'<line x1="22" y1="2" x2="11" y2="13"/><path d="M22 2l-7 20-4-9-9-4 20-7z"/>',
    search:'<circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.5" y2="16.5"/>',
    visibility:'<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>',
    edit_document:'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6"/><polyline points="14 3 14 8 19 8"/><path d="M19 13.5l3 3-4.5 4.5H14v-3.5l5-4z"/>',
    school:'<path d="M3 9l9-4 9 4-9 4-9-4z"/><path d="M7 11v4c0 1.2 2.2 3 5 3s5-1.8 5-3v-4"/><line x1="21" y1="9" x2="21" y2="14"/>',
    groups:'<circle cx="9" cy="9" r="3"/><path d="M3 19a6 6 0 0 1 12 0"/><circle cx="17.5" cy="9" r="2.2"/><path d="M16 13.5A5 5 0 0 1 21 18.5"/>',
    forest:'<path d="M12 3l4 6h-2.5l3 5h-9l3-5H8l4-6z"/><line x1="12" y1="14" x2="12" y2="21"/>',
    eco:'<path d="M5 18C4 12 8 5 19 5c0 11-7 14-13 12z"/><path d="M5 19c3-5 7-8 11-9"/>',
    apartment:'<rect x="6" y="3" width="12" height="18" rx="1"/><line x1="9" y1="7" x2="10" y2="7"/><line x1="14" y1="7" x2="15" y2="7"/><line x1="9" y1="11" x2="10" y2="11"/><line x1="14" y1="11" x2="15" y2="11"/><line x1="9" y1="15" x2="10" y2="15"/><line x1="14" y1="15" x2="15" y2="15"/><line x1="11" y1="21" x2="13" y2="21"/>',
    local_library:'<path d="M4 5a2 2 0 0 1 2-2h5v17H6a2 2 0 0 0-2 2V5z"/><path d="M20 5a2 2 0 0 0-2-2h-5v17h5a2 2 0 0 1 2 2V5z"/>',
    menu_book:'<path d="M4 5a2 2 0 0 1 2-2h5v17H6a2 2 0 0 0-2 2V5z"/><path d="M20 5a2 2 0 0 0-2-2h-5v17h5a2 2 0 0 1 2 2V5z"/>',
    format_quote:'<path d="M6 7h4v4c0 2.5-1.5 4-4 4"/><path d="M14 7h4v4c0 2.5-1.5 4-4 4"/>',
    emoji_events:'<path d="M8 4h8v4a4 4 0 0 1-8 0V4z"/><path d="M8 5.5H5.5v1.5a3 3 0 0 0 3 3"/><path d="M16 5.5h2.5v1.5a3 3 0 0 1-3 3"/><line x1="12" y1="12" x2="12" y2="16"/><rect x="9.5" y="16" width="5" height="4" rx="1"/><line x1="8" y1="20" x2="16" y2="20"/>',
    military_tech:'<circle cx="12" cy="8.5" r="4"/><polyline points="9 12 8 21 12 19 16 21 15 12"/>',
    workspace_premium:'<circle cx="12" cy="9" r="5.2"/><path d="M12 6.6l.9 1.9 2 .3-1.5 1.4.4 2-1.8-1-1.8 1 .4-2-1.5-1.4 2-.3.9-1.9z" fill="currentColor" stroke="none"/><polyline points="9 14.5 8 21 12 19 16 21 15 14.5"/>',
    verified:'<path d="M12 2.4l2.3 1.7 2.8-.2.6 2.8 2.5 1.4-1 2.7 1 2.7-2.5 1.4-.6 2.8-2.8-.2L12 21.6l-2.3-1.7-2.8.2-.6-2.8L3.8 16l1-2.7-1-2.7 2.5-1.4.6-2.8 2.8.2L12 2.4z"/><polyline points="8.5 12 11 14.5 15.5 9.5"/>',
    grade:'<path d="M12 3l2.6 5.6 6 .7-4.4 4 1.2 5.9L12 22l-5.4-2.8 1.2-5.9-4.4-4 6-.7L12 3z" fill="currentColor" stroke="none"/>',
    rocket_launch:'<path d="M12 3c3 2.2 4.2 6 4 9.5L14 16h-4l-2-3.5C7.8 9 9 5.2 12 3z"/><circle cx="12" cy="9" r="1.5"/><path d="M8 15l-3 1.2 1.2 3 3-1.2"/><path d="M16 15l3 1.2-1.2 3-3-1.2"/>',
    lightbulb:'<path d="M9 18h6"/><path d="M10 21h4"/><path d="M12 3a6 6 0 0 0-4 10.5c.7.8 1 1.5 1 2.5h6c0-1 .3-1.7 1-2.5A6 6 0 0 0 12 3z"/>',
    child_care:'<circle cx="12" cy="12" r="9"/><circle cx="9" cy="11" r="1" fill="currentColor" stroke="none"/><circle cx="15" cy="11" r="1" fill="currentColor" stroke="none"/><path d="M9 14.5a4 4 0 0 0 6 0"/>',
    auto_stories:'<path d="M12 6c-2-1.4-4-1.9-8-1.9V17c4 0 6 .5 8 1.9 2-1.4 4-1.9 8-1.9V4.1c-4 0-6 .5-8 1.9z"/><line x1="12" y1="6" x2="12" y2="18.9"/>',
    cast_for_education:'<rect x="3" y="6" width="18" height="11" rx="1"/><path d="M3 20h6"/><path d="M9 10.5l3-1.4 3 1.4-3 1.4-3-1.4z"/><path d="M15 10.5v1.6c0 1-1.4 1.9-3 1.9s-3-.9-3-1.9"/>',
    meeting_room:'<line x1="4" y1="21" x2="20" y2="21"/><rect x="7" y="3.5" width="9" height="17.5"/><circle cx="13.5" cy="13" r="1" fill="currentColor" stroke="none"/>',
    directions_bus:'<rect x="4" y="4" width="16" height="13" rx="2"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="8.5" y1="4" x2="8.5" y2="12"/><line x1="15.5" y1="4" x2="15.5" y2="12"/><circle cx="8" cy="19" r="1.4"/><circle cx="16" cy="19" r="1.4"/>',
    sports_handball:'<circle cx="15" cy="5" r="2"/><path d="M15 8l-2.5 3 3 2"/><path d="M12.5 11L11 16l-2 4"/><path d="M15.5 13l3 2"/><circle cx="6.5" cy="10" r="2"/>',
    track_changes:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill="currentColor" stroke="none"/>',
    handshake:'<path d="M11 8l2-1.8a2 2 0 0 1 2.8 0L20 10l-3.5 3.5L14 11"/><path d="M11 8L8.2 6.2a2 2 0 0 0-2.8 0L4 7.6 7 11l2-1.8"/><path d="M9 12l2 2 2-2 2 2"/>',
    health_and_safety:'<path d="M12 3l7 3v5c0 5-3 8-7 10-4-2-7-5-7-10V6l7-3z"/><line x1="12" y1="8.5" x2="12" y2="14.5"/><line x1="9" y1="11.5" x2="15" y2="11.5"/>',
    diversity_3:'<circle cx="12" cy="6" r="2"/><circle cx="6" cy="14" r="2"/><circle cx="18" cy="14" r="2"/><path d="M9 20a3 3 0 0 1 6 0"/><path d="M3 21a3 3 0 0 1 5-1.6"/><path d="M21 21a3 3 0 0 0-5-1.6"/>',
    extension:'<path d="M4 8h3a2 2 0 1 1 4 0h3v3a2 2 0 1 1 0 4v3h-3a2 2 0 1 0-4 0H4v-3a2 2 0 1 0 0-4V8z"/>',
    sentiment_very_satisfied:'<circle cx="12" cy="12" r="9"/><circle cx="9" cy="10" r="1" fill="currentColor" stroke="none"/><circle cx="15" cy="10" r="1" fill="currentColor" stroke="none"/><path d="M8 13.5a4 4 0 0 0 8 0z" fill="currentColor" stroke="none"/>',
    account_balance:'<path d="M4 9l8-5 8 5"/><line x1="3.5" y1="9" x2="20.5" y2="9"/><line x1="6" y1="9" x2="6" y2="17"/><line x1="10" y1="9" x2="10" y2="17"/><line x1="14" y1="9" x2="14" y2="17"/><line x1="18" y1="9" x2="18" y2="17"/><line x1="3" y1="20" x2="21" y2="20"/>',
    volunteer_activism:'<path d="M12 7.5c1-1.8 4-1.4 4 .9 0 2-4 3.6-4 3.6s-4-1.6-4-3.6c0-2.3 3-2.7 4-.9z"/><path d="M3 14l4-1 5 1.4 3-1 5 2.2"/><path d="M3 14v4h13l4-2"/>',
    auto_awesome:'<path d="M12 3l1.8 4.2L18 9l-4.2 1.8L12 15l-1.8-4.2L6 9l4.2-1.8L12 3z"/><path d="M18.5 14l.6 1.5 1.5.6-1.5.6-.6 1.5-.6-1.5-1.5-.6 1.5-.6.6-1.5z" fill="currentColor" stroke="none"/>',
    gavel:'<path d="M13.5 4l4 4-3 3-4-4 3-3z"/><line x1="9" y1="9" x2="13.5" y2="13.5"/><line x1="4" y1="20" x2="10" y2="14"/><line x1="13" y1="20" x2="21" y2="20"/>',
    insights:'<path d="M4 18l5-5 3 3 6-7"/><circle cx="9" cy="13" r="1.2" fill="currentColor" stroke="none"/><circle cx="12" cy="16" r="1.2" fill="currentColor" stroke="none"/><circle cx="18" cy="9" r="1.2" fill="currentColor" stroke="none"/>',
    local_hospital:'<rect x="4" y="4" width="16" height="16" rx="2"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/>',
    sell:'<path d="M3 12l9-9h7v7l-9 9-7-7z"/><circle cx="15.5" cy="8.5" r="1.4" fill="currentColor" stroke="none"/>',
    play_arrow:'<path d="M8 5v14l11-7-11-7z" fill="currentColor" stroke="none"/>',
    play_circle:'<circle cx="12" cy="12" r="9"/><path d="M10 8.5v7l6-3.5-6-3.5z" fill="currentColor" stroke="none"/>'
  };
  window.APS_ICONS = I;
  window.apsSvg = function (n) { return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' + (I[n] || '') + '</svg>'; };
  function fill(){
    document.querySelectorAll('.sym').forEach(function (el) {
      if (el.querySelector('svg')) return;
      var n = (el.textContent || '').trim();
      if (I[n] !== undefined) el.innerHTML = window.apsSvg(n);
      el.setAttribute('aria-hidden', 'true');
    });
  }
  fill();
  document.addEventListener('DOMContentLoaded', fill);
})();
