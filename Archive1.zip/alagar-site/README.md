# Alagar Public School — New Website

A fresh, modern, responsive multi-page website for Alagar Public School, built to feel more premium than the Stonehill and Kalyani reference sites while keeping all the provided content.

## Pages (9 main menus)
| File | Menu | Sub-sections (anchors) |
|------|------|------------------------|
| `index.html` | Home | Hero, Why Alagar, Learning Ladder, Proof, Testimonials, News |
| `about.html` | About Us | Origin, Vision & Mission, Chairman, Correspondent, Principal, Mandatory Disclosure, Annual Report |
| `academics.html` | Academics | Foundation, Discoverers, Innovators, Trailblazers, Student Council, Book List |
| `admission.html` | Admission | Procedure, Age & Documents, Enquiry Form, Rules, Examination, TC |
| `resources.html` | Resources | Facilities, Transport, New Initiatives, Field Trips, Disclosures |
| `student-life.html` | Student Life | Activities, Competitions, Achievement, Gallery |
| `news-events.html` | News & Events | Latest News, Calendar, Circulars, Newsletter |
| `careers.html` | Careers | Why Join Us, Openings, Application Form |
| `contact.html` | Contact Us | Info, Message form, Map |

The sub-navigation in the dropdown menus links directly to the matching section on each page.

## How it's built
- **Material Design 3 (Material You).** A full M3 design system: colour roles (primary/secondary/tertiary, surfaces, outline), five elevation levels, M3 shape scale, tonal cards, filled/tonal/outlined/text buttons, a FAB, expansion panels and filled text fields.
- **`assets/css/styles.css`** — the complete Material design system.
- **`assets/js/main.js`** — builds the shared **top app bar** (with hover menus) and a **navigation drawer** for mobile, plus the footer; handles sticky elevation, drawer, count-up stats, scroll reveal and form handling.
- Icons: **Material Symbols Rounded**. Fonts: **Roboto** via Google Fonts.
- Colour seeded from the school green with a gold tertiary accent.
- **Logo:** shows the logo image only — the "Aspire · Perform · Soar" slogan was removed from the header and footer (the wordmark already lives inside the logo image, so the name text was dropped too to avoid duplication).

## De-duplication
Content was consolidated so each fact lives in one canonical place: the headline stats band appears only on Home; board-results figures only on Admission → Examination; the full testimonial set only on Student Life (Home shows two teasers); Home covers *why-choose* value props while Resources covers *facilities/initiatives*; CTAs are page-specific.

## To open
Double-click `index.html`. (For the dynamic header/footer to load, open it in a browser — they are injected by `main.js`.)

## Notes for going live
- **Logo:** pages currently load the existing `image_0.png` from the parent folder. To make the site fully self-contained, drop the logo into `assets/img/logo.png` and change the path back in `main.js` and the `<link rel="icon">` tags.
- **Images:** decorative SVG placeholders are used where real photos aren't available (hero, gallery, news). Replace with real campus photographs.
- **Forms:** enquiry/contact/newsletter forms show a success message on submit. Connect them to your email service or backend to actually receive submissions.
- **Links marked `#`:** Pay Online, Privacy Policy, Terms, and some circular/news links are placeholders to be wired up.
- Verify the exact Google Maps location on `contact.html`.
